# 평가

- `evaluate.py`가 테스트셋 정확도와 **Confusion Matrix**를 생성
- 결과:
  - `Output/test_metrics.json`
  - `Output/confusion_matrix.png`
