# STM32 디버깅/데모 팁

- Putty 시리얼: 115200bps (예: COM9)
- 콘솔 명령: `asc start|stop`, `help`, `info` 등
- `SENSING1_USE_PRINTF` 활성화로 UART 로그 확인
- 모바일 앱(ST BLE Sensor) 연동 전, `home.wav/park.wav/bus.wav`로 사전 검증
